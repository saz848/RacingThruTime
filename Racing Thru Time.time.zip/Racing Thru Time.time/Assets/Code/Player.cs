﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Code
{
    public class Player : Character
    {

        // Use this for initialization
        void Start()
        {
            progress = MaxProgress;
            direction = 0;
            all_wp = FindObjectsOfType<Waypoint>();
            to = FindClosestWaypoint(transform.position);
            ChooseDirection(to, direction);
            g = FindObjectOfType<Goal>();
        }

        // Update is called once per frame
        void Update()
        {
            float distance = Vector3.Distance(transform.position, g.transform.position);
            if (distance < (radius + g.radius))
            {
                Game.EndGame(Game.VICTORY);
            }
        }
    }
}

