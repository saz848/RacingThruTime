﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlusTile : MonoBehaviour {
    Quaternion fromAngle;
    Quaternion toAngle;
    bool rotateCCW = false;
    float target = 0; 
    bool rotateCC = false;

	// Use this for initialization
	void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown(KeyCode.X))
        {
            rotateCC = true;
            target -= 90;
        }

        if (rotateCC)
        { transform.Rotate(Vector3.back * 1.5f); }

        if (transform.localRotation == Quaternion.Euler(0, 0, target))
        {
            rotateCC = false;
            transform.Rotate(Vector3.zero);
        }

        if (Input.GetKeyDown(KeyCode.Z))
        {
            rotateCCW = true;
            target += 90;
        }

        if (rotateCCW)
        { transform.Rotate(Vector3.forward* 1.5f); }

        if (transform.localRotation == Quaternion.Euler(0, 0, target))
        {
            rotateCCW = false;
            transform.Rotate(Vector3.zero);
        }

    }




}
